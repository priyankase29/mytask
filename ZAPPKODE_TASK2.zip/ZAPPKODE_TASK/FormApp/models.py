from tkinter import Widget
from typing_extensions import Required
from django.db import models
from django import forms

# Create your models here.
class Register(models.Model):
    id = models.AutoField(primary_key=True, Required = True)
    username = models.CharField(max_length=100, Required = True)
    email = models.EmailField(max_length=100, Required = True)
    contact = models.CharField(max_length=100, Required = True)
    password = models.CharField(max_length=100, Required = True, Widget = forms.PasswordInput)
    repassword = models.CharField(max_length=100, Required = True)
    Timestamp = models.DateTimeField(auto_now_add=True, blank=True, Required = True)

    def __str__(self):
        return self.contname