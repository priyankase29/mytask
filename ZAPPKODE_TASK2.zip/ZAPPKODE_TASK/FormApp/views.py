from django.shortcuts import redirect, render

# Create your views here.


def register(request):
    # if request.method == 'POST':
    #     username = request.POST.get('username')
    #     email = request.POST.get('email')
    #     password = request.POST.get('password')
    #     price = request.POST.get('price')
    #     contact = request.POST.get('contact')
      
    #     try:
    #         if User.objects.filter(username=username).first():
    #             messages.error(request, 'username already exist')
    #             return redirect('/register/<str:num>/')
    #         if User.objects.filter(email=email).first():
    #             messages.error(request, 'email already exist')
    #             return redirect('/register/<str:num>/')
    #         user_obj = User.objects.create(username=username, email=email)
    #         user_obj.set_password(password)
    #         user_obj.save()
 
    #         auth_token = str(uuid.uuid4())
    #         profile_obj = profile.objects.create(user=user_obj, auth_token=auth_token,price=price,contact=contact)
    #         profile_obj.save()
    #         send_email_after_register(email, auth_token)
    #         return redirect('/token_send')
    #     except Exception as e:
    #         print(e)

      if request.method == 'POST':
             

      return render(request, 'FormApp/register.html')






def login(request):
        # if request.method == 'POST':
        #     username = request.POST.get('username')
        #     password = request.POST.get('password')

        #     user_obj = User.objects.filter(username=username).first()
        #     if user_obj is None:
        #         messages.success(request, 'user not found')
        #         return redirect('/login')

        #     profile_obj = profile.objects.filter(user=user_obj).first()
        #     if not profile_obj.is_verified:
        #         messages.success(
        #             request, 'Profile is not verify check your mail')
        #         return redirect('/login')

        #     user = authenticate(username=username, password=password)
        #     if user is None:
        #         messages.success(request, 'Wrong password')
        #         return redirect('/login')

        #     auth_login(request, user)
        #     return redirect('/home')

        return render(request, 'FormApp/login.html')