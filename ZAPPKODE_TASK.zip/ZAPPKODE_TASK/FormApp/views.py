from django import forms
from django.shortcuts import redirect, render
from django.contrib import messages
from .models import Register
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth.decorators import login_required


# Create your views here.

def home(request):
    return render(request, 'FormApp/home.html')




def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        # last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        contact = request.POST.get('contact')
        password = request.POST.get('password')
        repassword = request.POST.get('repassword')
      
        
        if Register.objects.filter(username=username).first():
          messages.error(request, 'username already exist')
          return redirect('/')
        if Register.objects.filter(email=email).first():
          messages.error(request, 'email already exist')
          return redirect('/')
        if password != repassword:
          messages.error(request, 'Password is not same')
          return redirect('/')
            # user_obj = User.objects.create(username=username, email=email)
            # user_obj.set_password(password)
            # user_obj.save()

            # auth_token = str(uuid.uuid4())
        Register_obj = Register.objects.create(username=username,email=email,contact=contact,password=password,repassword=repassword,)
        Register_obj.save()
        return redirect('/login')
       

             

    return render(request, 'FormApp/register.html')






def login(request):
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            # Register_obj = Register.objects.filter(username=username).first()
            # if Register_obj is None:
            #     messages.error(request, 'user not found')
            #     return redirect('/login')

            # # Register_obj = Register.objects.filter(username=username).first()
            # # if not Register_obj.is_verified:
            # #     messages.success(
            # #         request, 'Profile is not verify check your mail')
            # #     return redirect('/login')

            # user = authenticate(username=username, password=password)
            # if user is None:
            #     messages.error(request, 'Wrong password')
            #     return redirect('/login')

            # auth_login(request, user)
            # return redirect('/home')



            Register_obj = Register.objects.filter(username=username).first()
            if Register_obj is None:
                messages.error(request, 'user not found')
                return redirect('/login')

            # profile_obj = profile.objects.filter(user=user_obj).first()
            # if not profile_obj.is_verified:
            #     messages.success(
            #         request, 'Profile is not verify check your mail')
            #     return redirect('/login')

            Regis= authenticate(username=username, password=password)
            if Regis is None:
                messages.error(request, 'Wrong password')
                return redirect('/login')

            auth_login(request, Regis)
            return redirect('/home')

        

        return render(request, 'FormApp/login.html')