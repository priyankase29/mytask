from django.contrib import admin
from FormApp.models import Register

# Register your models here.
admin.site.register(Register)

# Register your models here.
