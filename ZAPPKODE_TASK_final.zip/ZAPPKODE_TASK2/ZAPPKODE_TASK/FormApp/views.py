from django.shortcuts import redirect, render
from .models import Register

# Create your views here.


def register(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        contact = request.POST['contact']
        password = request.POST['password']
        repassword = request.POST['repassword']
        Register.objects.create(username=username, email=email, contact=contact,password=password,repassword=repassword)


    return render(request, 'FormApp/register.html')






def login(request):
        # if request.method == 'POST':
        #     username = request.POST.get('username')
        #     password = request.POST.get('password')

        #     user_obj = User.objects.filter(username=username).first()
        #     if user_obj is None:
        #         messages.success(request, 'user not found')
        #         return redirect('/login')

        #     profile_obj = profile.objects.filter(user=user_obj).first()
        #     if not profile_obj.is_verified:
        #         messages.success(
        #             request, 'Profile is not verify check your mail')
        #         return redirect('/login')

        #     user = authenticate(username=username, password=password)
        #     if user is None:
        #         messages.success(request, 'Wrong password')
        #         return redirect('/login')

        #     auth_login(request, user)
        #     return redirect('/home')

        return render(request, 'FormApp/login.html')