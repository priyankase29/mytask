from tkinter import Widget
from django.db import models
from django import forms

# Create your models here.
class Register(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    contact = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    repassword = models.CharField(max_length=100)
    Timestamp = models.DateTimeField(auto_now_add=True, blank=True)

    def __str__(self):
        return self.username